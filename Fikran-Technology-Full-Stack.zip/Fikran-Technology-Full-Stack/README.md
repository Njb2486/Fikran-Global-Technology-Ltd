# Fikran Technology — Website + Django API starter

This ZIP contains:
- `frontend/`: responsive black-and-gold HTML/CSS/JavaScript website.
- `backend/`: Django REST Framework starter API, health endpoint, public services endpoint and JWT token endpoints.

## 1. Run the website
Open `frontend/index.html` in a browser, or use VS Code Live Server.
The API address is configured in `frontend/js/config.js`.

## 2. Run the backend on Windows
1. Install Python 3.11 or newer.
2. Open a terminal inside the `backend` folder.
3. Create a virtual environment: `py -m venv .venv`
4. Activate it: `.venv\\Scripts\\activate`
5. Install packages: `pip install -r requirements.txt`
6. Copy `.env.example` to `.env` and set a strong `DJANGO_SECRET_KEY`.
7. Run: `py manage.py migrate`
8. Run: `py manage.py runserver`

Test in your browser: `http://127.0.0.1:8000/api/health/`
Admin setup: `py manage.py createsuperuser`, then visit `/admin/`.

## 3. Connect frontend to API
For local development, `frontend/js/config.js` uses:
`http://127.0.0.1:8000/api`
If the frontend runs on a different port, add its exact origin to `CORS_ALLOWED_ORIGINS` in `.env`.
For production, change `API_BASE_URL` to your deployed HTTPS API address and configure the exact frontend domain in CORS.

## 4. Important production/security notes
- This is a starter foundation, not a complete fintech or production payment system.
- JWT endpoints use Django's default user model. Create users through a properly designed registration flow before enabling customer accounts.
- No wallet balance, deposits, withdrawals, transfers, KYC or payment-provider webhook is enabled in this starter.
- Implement provider-specific payment verification and webhook signature handling on the server only. Never trust browser-submitted payment success or amounts.
- Never put secret API keys, database passwords, Django secret keys or webhook secrets in frontend HTML/CSS/JavaScript or a public repository.
- Before deployment: set `DEBUG=False`, a unique strong `DJANGO_SECRET_KEY`, production `ALLOWED_HOSTS`, HTTPS, database backups, logging, rate limits and security review.
