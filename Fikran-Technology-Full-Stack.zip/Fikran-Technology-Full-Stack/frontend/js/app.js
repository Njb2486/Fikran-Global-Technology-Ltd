const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
if (menuToggle && mainNav) {
  menuToggle.addEventListener("click", () => {
    const open = mainNav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(open));
    menuToggle.textContent = open ? "×" : "☰";
  });
  mainNav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  }));
}
document.getElementById("year").textContent = new Date().getFullYear();

async function checkApi() {
  const statusEl = document.getElementById("apiStatus");
  const base = window.FIKRAN_CONFIG?.API_BASE_URL;
  if (!base) { statusEl.textContent = "API address is not configured."; return; }
  try {
    const response = await fetch(`${base}/health/`, {headers: {"Accept": "application/json"}});
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const result = await response.json();
    statusEl.textContent = result.status === "ok"
      ? "● Fikran API connected"
      : "API responded, but health status needs attention.";
    statusEl.classList.toggle("connected", result.status === "ok");
  } catch (error) {
    statusEl.textContent = "○ API not connected yet — website preview is available.";
    statusEl.classList.remove("connected");
  }
}
checkApi();
