// Set this to your deployed Django API base URL before publishing the frontend.
window.FIKRAN_CONFIG = {
  API_BASE_URL: "http://127.0.0.1:8000/api"
};
