from django.db import models
# Add business models here as the product requirements are finalised.
