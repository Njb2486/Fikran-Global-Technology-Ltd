from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny

class HealthView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []
    def get(self, request):
        return Response({"status": "ok", "service": "Fikran Technology API"})

class ServiceListView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []
    def get(self, request):
        services = [
            {"id": "software-web", "name": "Software & Web", "description": "Websites, applications and business platforms."},
            {"id": "fintech", "name": "Fintech Solutions", "description": "Payment technology and digital financial services."},
            {"id": "digital-services", "name": "Digital Services", "description": "Business support and digital access."},
            {"id": "academy", "name": "Learning & Research", "description": "Technology education, skills and research."},
        ]
        return Response({"results": services})
